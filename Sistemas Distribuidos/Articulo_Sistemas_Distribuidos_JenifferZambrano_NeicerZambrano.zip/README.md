# Plantilla latex para publicación de artículo científico en la revista "La Mecatrónica en México" (ISSN: 2448-7031).

Favor de enviar sus comentarios o correcciones a los autores o mediante pull-request
- juan.avina.m@gmail.com

Plantilla basada en los requerimientos planteados en [Formato de artículo para revista La Mecatrónica en México] (http://www.mecamex.net/revistas/LMEM/Formato_Articulo.docx)